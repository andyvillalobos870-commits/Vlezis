# Vlezis PWA

Archivos listos para GitHub Pages.

## Estructura
- index.html
- manifest.json
- service-worker.js
- icons/icon-192.png
- icons/icon-512.png

## GitHub Pages
Sube todo manteniendo esta estructura. Luego ve a:
Settings → Pages → Deploy from a branch → main → /(root) → Save.

Cuando GitHub publique la URL, ábrela en Android y elige "Instalar app" o "Añadir a pantalla de inicio".

El icono incluido es provisional. Si tienes el PNG oficial de Vlezis, reemplaza ambos iconos por versiones 192x192 y 512x512.
